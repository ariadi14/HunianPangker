# HunianPangker — Firebase setup

Firebase configuration is connected to the Android application package `com.hunianpangker.app`.

## Included in this source
- `app/google-services.json`
- Google Services Gradle plugin 4.5.0
- Firebase Android BoM 34.19.0
- Firebase Analytics
- Firebase Authentication
- Cloud Firestore
- `FirebaseRepository.kt` for registration, login, profile storage and logout

## Required console steps
1. Firebase Console → Authentication → Sign-in method → enable **Email/Password**.
2. Firebase Console → Firestore Database → Create database.
3. The database was created in production mode. Apply `firestore.rules` from this project before using client-side profile writes.

## User profile structure
Collection: `users/{uid}`
- `nama`
- `email`
- `role`: `pencari` or `pemilik`
- `foto`
- `createdAt`

The 10-screen blueprint UI is intentionally unchanged in this Firebase foundation step.

## Current Firestore security scope

The included `firestore.rules` allows an authenticated user to read and write only `users/{their-own-uid}`. Other collections are denied until their feature and rules are deliberately implemented.

## Current Firebase status
- Firestore database ID: `(default)`
- Firestore location: `asia-southeast2 (Jakarta)`
- Firestore mode: Production
- Authentication provider: Email/Password enabled
