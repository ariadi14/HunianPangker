package com.hunianpangker.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage

private val Gold = Color(0xFFF2B632)
private val GoldDark = Color(0xFFB77B00)
private val Green = Color(0xFF1F6B45)
private val GreenDark = Color(0xFF0E3D2B)
private val Red = Color(0xFFC73535)
private val Ink = Color(0xFF111111)
private val Soft = Color(0xFFF7F7F5)
private val Border = Color(0xFFE4E2DC)

private data class Listing(val id:Int,val title:String,val type:String,val price:String,val address:String,val distance:String,val rating:String,val reviews:Int,val image:String,val available:String)
private val demoListings = listOf(
    Listing(1,"Kos Melati","Kos","Rp 750.000/bulan","Jl. Lintas Timur, Pangkalan Kerinci","800 m dari lokasi Anda","4.8",23,"https://images.pexels.com/photos/7587880/pexels-photo-7587880.jpeg?auto=compress&cs=tinysrgb&w=1200","Tersedia"),
    Listing(2,"Kos Anggrek","Kos","Rp 650.000/bulan","Jl. Pemda, Pangkalan Kerinci","1,2 km","4.6",18,"https://images.pexels.com/photos/7031607/pexels-photo-7031607.jpeg?auto=compress&cs=tinysrgb&w=1200","Tersedia"),
    Listing(3,"Kontrakan Sederhana","Kontrakan","Rp 1.200.000/bulan","Jl. Maharaja Indra","2,1 km","4.7",31,"https://images.pexels.com/photos/8134821/pexels-photo-8134821.jpeg?auto=compress&cs=tinysrgb&w=1200","Tersedia"),
    Listing(4,"Rumah Minimalis","Rumah","Rp 2.500.000/bulan","Jl. Camar","2,8 km","4.5",12,"https://images.pexels.com/photos/8134820/pexels-photo-8134820.jpeg?auto=compress&cs=tinysrgb&w=1200","Segera Tersedia"),
    Listing(5,"Kos Putri Rahma","Kos","Rp 550.000/bulan","Jl. Hangtuah","3,1 km","4.9",27,"https://images.pexels.com/photos/8583636/pexels-photo-8583636.jpeg?auto=compress&cs=tinysrgb&w=1200","Tersedia")
)

enum class Screen { Splash, Home, Search, Results, Map, Detail, Reviews, Owner, Add, Account }

class HunianTheme {
    companion object {
        @Composable fun Content(content: @Composable () -> Unit) { MaterialTheme(colorScheme = lightColorScheme(primary=Green, secondary=Gold, background=Color.White, surface=Color.White)) { content() } }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { HunianTheme.Content { App() } } }
}

@Composable private fun App() {
    var screen by remember { mutableStateOf(Screen.Splash) }
    var selected by remember { mutableStateOf(demoListings.first()) }
    var roleOwner by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(900); screen = Screen.Home }
    when(screen) {
        Screen.Splash -> Splash()
        Screen.Home -> Home(onSearch={screen=Screen.Search}, onOwner={roleOwner=true;screen=Screen.Owner}, onSelect={selected=it;screen=Screen.Detail}, onNav={screen=it})
        Screen.Search -> Search(onBack={screen=Screen.Home}, onApply={screen=Screen.Results}, onNav={screen=it})
        Screen.Results -> Results(onBack={screen=Screen.Search}, onMap={screen=Screen.Map}, onSelect={selected=it;screen=Screen.Detail}, onNav={screen=it})
        Screen.Map -> MapScreen(onBack={screen=Screen.Results}, onSelect={selected=demoListings.first();screen=Screen.Detail}, onNav={screen=it})
        Screen.Detail -> Detail(listing=selected,onBack={screen=Screen.Results},onReviews={screen=Screen.Reviews},onOwner={roleOwner=true;screen=Screen.Owner})
        Screen.Reviews -> Reviews(onBack={screen=Screen.Detail})
        Screen.Owner -> Owner(onBack={screen=Screen.Home},onAdd={screen=Screen.Add},onAccount={screen=Screen.Account},onNav={screen=it})
        Screen.Add -> AddListing(onBack={screen=Screen.Owner},onDone={screen=Screen.Owner})
        Screen.Account -> Account(onBack={screen=Screen.Home},onNav={screen=it})
    }
}

@Composable private fun Splash() {
    Box(Modifier.fillMaxSize().background(Color.White),contentAlignment=Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Image(painter=androidx.compose.ui.res.painterResource(com.hunianpangker.app.R.drawable.hunianpangker_logo),contentDescription="HunianPangker",modifier=Modifier.size(250.dp),contentScale=ContentScale.Fit)
        }
    }
}

@Composable private fun LogoHeader(modifier:Modifier=Modifier) { Row(modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically) { Image(painter=androidx.compose.ui.res.painterResource(R.drawable.hunianpangker_logo),contentDescription=null,modifier=Modifier.size(54.dp)); Spacer(Modifier.width(10.dp)); Column { Text("HunianPangker",fontWeight=FontWeight.ExtraBold,fontSize=22.sp,color=Ink); Text("PANGKALAN KERINCI",fontSize=9.sp,fontWeight=FontWeight.Bold,color=Green,letterSpacing=2.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.NotificationsNone,null,tint=Ink) } }

@Composable private fun BottomNav(active:Screen,onNav:(Screen)->Unit) { NavigationBar(containerColor=Color.White,tonalElevation=6.dp) { listOf(Screen.Home to ("Beranda" to Icons.Rounded.Home), Screen.Search to ("Cari" to Icons.Rounded.Search), Screen.Results to ("Favorit" to Icons.Rounded.FavoriteBorder), Screen.Owner to ("Pesan" to Icons.Rounded.ChatBubbleOutline), Screen.Account to ("Akun" to Icons.Rounded.Person)).forEach { (s,p)-> NavigationBarItem(selected=active==s,onClick={onNav(s)},icon={Icon(p.second,null)},label={Text(p.first,fontSize=10.sp)}) } } }

@Composable private fun Home(onSearch:()->Unit,onOwner:()->Unit,onSelect:(Listing)->Unit,onNav:(Screen)->Unit) { Scaffold(bottomBar={BottomNav(Screen.Home,onNav)}) { pad-> LazyColumn(Modifier.fillMaxSize().padding(pad).background(Color.White)) { item { LogoHeader() }; item { SearchBar("Mau cari hunian apa?",onSearch) }; item { Spacer(Modifier.height(12.dp)); Text("Kategori Populer",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(horizontal=20.dp)); Row(Modifier.horizontalScroll(rememberScrollState()).padding(20.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) { listOf("Kos" to Icons.Rounded.Business,"Kontrakan" to Icons.Rounded.HomeWork,"Rumah" to Icons.Rounded.Home,"Kamar" to Icons.Rounded.Bed).forEach { Category(it.first,it.second) } } }; item { HeroBanner() }; item { SectionTitle("Hunian Terbaru","Lihat Semua") }; items(demoListings.take(3)) { ListingRow(it,onSelect) }; item { OwnerCTA(onOwner) } } } }

@Composable private fun SearchBar(text:String,onClick:()->Unit) { Surface(modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(16.dp),color=Color.White,shadowElevation=2.dp,border=BorderStroke(1.dp, Border)) { Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Rounded.Search,null,tint=Green);Spacer(Modifier.width(10.dp));Text(text,color=Color.Gray);Spacer(Modifier.weight(1f));Icon(Icons.Rounded.Tune,null,tint=GoldDark)} } }
@Composable private fun Category(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector){Surface(shape=RoundedCornerShape(16.dp),color=Soft,border=BorderStroke(1.dp, Border)){Column(Modifier.width(82.dp).padding(13.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=Green);Spacer(Modifier.height(7.dp));Text(label,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}
@Composable private fun HeroBanner(){Box(Modifier.padding(20.dp).fillMaxWidth().height(140.dp).clip(RoundedCornerShape(20.dp))){AsyncImage(model=demoListings[2].image,contentDescription=null,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.38f)));Column(Modifier.padding(18.dp)){Text("Temukan Hunian Ideal",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Text("di Pangkalan Kerinci",color=Gold,fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Text("Nyaman • Strategis • Terpercaya",color=Color.White,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}
@Composable private fun SectionTitle(a:String,b:String){Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Text(a,fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text(b,color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)}}
@Composable private fun ListingRow(x:Listing,onClick:(Listing)->Unit){Card(Modifier.padding(horizontal=20.dp,vertical=6.dp).fillMaxWidth().clickable{onClick(x)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(10.dp)){AsyncImage(model=x.image,contentDescription=null,modifier=Modifier.size(105.dp).clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(x.title,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(x.price,color=GoldDark,fontWeight=FontWeight.ExtraBold);Text(x.address,fontSize=11.sp,color=Color.Gray,maxLines=1,overflow=TextOverflow.Ellipsis);Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Filled.Star,null,tint=Gold,modifier=Modifier.size(16.dp));Text(" ${x.rating} (${x.reviews})",fontSize=11.sp);Spacer(Modifier.weight(1f));StatusPill(x.available)}}}}}
@Composable private fun StatusPill(s:String){Surface(color=if(s=="Tersedia")Color(0xFFE7F7EA) else Color(0xFFFFF3D4),shape=RoundedCornerShape(50)){Text(s,color=if(s=="Tersedia")Green else GoldDark,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=8.dp,vertical=4.dp))}}
@Composable private fun OwnerCTA(onClick:()->Unit){Card(Modifier.padding(20.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){Column(Modifier.padding(18.dp)){Text("Punya kos atau rumah sewa?",color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp);Text("Pasang hunian Anda dan temukan calon penyewa.",color=Color.White.copy(.8f),fontSize=12.sp,modifier=Modifier.padding(top=4.dp));Button(onClick=onClick,colors=ButtonDefaults.buttonColors(containerColor=Gold),modifier=Modifier.padding(top=12.dp)){Text("Mulai Pasang Hunian",color=Ink,fontWeight=FontWeight.Bold)}}}}

@Composable private fun TopBar(title:String,onBack:()->Unit){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,null)};Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);Spacer(Modifier.weight(1f))}}
@Composable private fun Search(onBack:()->Unit,onApply:()->Unit,onNav:(Screen)->Unit){Scaffold(bottomBar={BottomNav(Screen.Search,onNav)}){p->LazyColumn(Modifier.fillMaxSize().padding(p)){item{TopBar("Cari Hunian",onBack)};item{SearchBar("Cari lokasi atau nama hunian...",{})};item{FilterSection()};item{Button(onClick=onApply,modifier=Modifier.fillMaxWidth().padding(20.dp),colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("Terapkan Filter",color=Ink,fontWeight=FontWeight.Bold)}}}}}
@Composable private fun FilterSection(){Column(Modifier.padding(horizontal=20.dp)){Text("Lokasi",fontWeight=FontWeight.Bold);FilterBox("📍  Pangkalan Kerinci");Text("Harga / bulan",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp));ChoiceRow(listOf("< 500rb","500rb - 1jt","1jt - 2jt","> 2jt"));Text("Jenis Hunian",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp));ChoiceRow(listOf("Kos","Kontrakan","Rumah","Kamar"));Text("Fasilitas",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp));ChoiceRow(listOf("Wi-Fi","Kamar Mandi","AC","Parkir","Dapur","Listrik","Air"));Text("Tipe Penghuni",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp));ChoiceRow(listOf("Putra","Putri","Keluarga","Bebas"))}}
@Composable private fun FilterBox(t:String){Surface(Modifier.fillMaxWidth().padding(top=8.dp),shape=RoundedCornerShape(14.dp),color=Soft){Text(t,modifier=Modifier.padding(15.dp),fontWeight=FontWeight.SemiBold)}}
@Composable private fun ChoiceRow(items:List<String>){Row(Modifier.horizontalScroll(rememberScrollState()).padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){items.forEachIndexed{i,x->Surface(shape=RoundedCornerShape(12.dp),color=if(i==0)Gold else Soft,border=BorderStroke(1.dp, Border)){Text(x,modifier=Modifier.padding(horizontal=12.dp,vertical=10.dp),fontSize=11.sp,fontWeight=FontWeight.SemiBold)}}}}

@Composable private fun Results(onBack:()->Unit,onMap:()->Unit,onSelect:(Listing)->Unit,onNav:(Screen)->Unit){Scaffold(bottomBar={BottomNav(Screen.Results,onNav)}){p->LazyColumn(Modifier.fillMaxSize().padding(p)){item{TopBar("Hasil Pencarian",onBack)};item{Row(Modifier.padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically){Text("42 hunian ditemukan",fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("Peta",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.clickable{onMap()})}};items(demoListings){ListingRow(it,onSelect)}}}}

@Composable private fun MapScreen(onBack:()->Unit,onSelect:()->Unit,onNav:(Screen)->Unit){Scaffold(bottomBar={BottomNav(Screen.Results,onNav)}){p->Box(Modifier.fillMaxSize().padding(p).background(Color(0xFFE8EEE8))){TopBar("Peta Lokasi",onBack);Column(Modifier.fillMaxSize().padding(top=72.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("PETA PANGKALAN KERINCI",fontWeight=FontWeight.ExtraBold,color=Green);Spacer(Modifier.height(50.dp));repeat(4){i->Row(Modifier.fillMaxWidth().padding(horizontal=(45+i*20).dp),horizontalArrangement=Arrangement.SpaceBetween){Icon(Icons.Filled.LocationOn,null,tint=if(i==0)Red else Gold,modifier=Modifier.size(34.dp));Text(listOf("Rp 650rb","Rp 750rb","Rp 800rb","Rp 1,2jt")[i],fontWeight=FontWeight.Bold,color=Ink)}};Spacer(Modifier.height(80.dp));Card(Modifier.padding(20.dp).clickable{onSelect()},shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(10.dp)){AsyncImage(model=demoListings.first().image,contentDescription=null,modifier=Modifier.size(90.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop);Column(Modifier.padding(start=10.dp)){Text("Kos Melati",fontWeight=FontWeight.Bold);Text("Rp 750.000/bulan",color=GoldDark,fontWeight=FontWeight.Bold);Text("800 m dari lokasi Anda",fontSize=11.sp)}}}}}}}

@Composable private fun Detail(listing:Listing,onBack:()->Unit,onReviews:()->Unit,onOwner:()->Unit){val ctx=LocalContext.current;LazyColumn(Modifier.fillMaxSize().background(Color.White)){item{Box(Modifier.fillMaxWidth().height(260.dp)){AsyncImage(model=listing.image,contentDescription=null,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop);IconButton(onClick=onBack,modifier=Modifier.padding(12.dp).background(Color.White.copy(.9f),RoundedCornerShape(50))){Icon(Icons.Rounded.ArrowBack,null)};IconButton(onClick={},modifier=Modifier.align(Alignment.TopEnd).padding(12.dp).background(Color.White.copy(.9f),RoundedCornerShape(50))){Icon(Icons.Rounded.FavoriteBorder,null)}}};item{Column(Modifier.padding(20.dp)){StatusPill(listing.available);Text(listing.title,fontSize=24.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.padding(top=10.dp));Text(listing.price,color=GoldDark,fontSize=19.sp,fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Filled.Star,null,tint=Gold);Text(" ${listing.rating} (${listing.reviews} ulasan)",fontWeight=FontWeight.Bold);Spacer(Modifier.width(10.dp));Icon(Icons.Filled.LocationOn,null,tint=Green);Text(listing.distance,fontSize=11.sp)};Spacer(Modifier.height(12.dp));Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Wi-Fi" to Icons.Filled.Wifi,"AC" to Icons.Filled.AcUnit,"Kamar Mandi" to Icons.Filled.Bathtub,"Parkir" to Icons.Filled.LocalParking,"Dapur" to Icons.Filled.Kitchen).forEach{Feature(it.first,it.second)}};Text("Deskripsi",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=18.dp));Text("Kos eksklusif, lingkungan aman dan nyaman, dekat kawasan industri. Cocok untuk karyawan dan mahasiswa.",color=Color.DarkGray,modifier=Modifier.padding(top=6.dp));Text("Ulasan & Rating",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=20.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("4.8",fontSize=34.sp,fontWeight=FontWeight.ExtraBold,color=GoldDark);Text("  ⭐⭐⭐⭐⭐  •  23 ulasan",fontSize=12.sp,modifier=Modifier.clickable{onReviews()})};Spacer(Modifier.height(70.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/6281234567890?text=Halo%20saya%20melihat%20Kos%20Melati%20di%20HunianPangker")))},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("Hubungi Pemilik")};OutlinedButton(onClick={},modifier=Modifier.weight(.5f)){Icon(Icons.Rounded.FavoriteBorder,null)}}}}}}
@Composable private fun Feature(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector){Surface(shape=RoundedCornerShape(14.dp),color=Soft){Column(Modifier.padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=Green,modifier=Modifier.size(20.dp));Text(t,fontSize=9.sp)}}}

@Composable private fun Reviews(onBack:()->Unit){LazyColumn(Modifier.fillMaxSize()){item{TopBar("Ulasan & Rating",onBack)};item{Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically){Text("4.8",fontSize=48.sp,fontWeight=FontWeight.ExtraBold,color=GoldDark);Column(Modifier.padding(start=18.dp)){Text("⭐⭐⭐⭐⭐");Text("23 ulasan",fontSize=12.sp,color=Color.Gray)}}};items(listOf("Siti Rahayu" to "Tempatnya bersih, sesuai foto. Pemilik ramah dan responsif. Lingkungan juga aman.","Andi Kurniawan" to "Lokasi strategis, dekat tempat kerja. Fasilitas lengkap.","Rina S." to "Kamar nyaman dan bersih.")){(n,c)->ReviewItem(n,c)};item{Button(onClick={},modifier=Modifier.fillMaxWidth().padding(20.dp),colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("Tulis Ulasan",color=Ink,fontWeight=FontWeight.Bold)}}}}
@Composable private fun ReviewItem(n:String,c:String){Card(Modifier.padding(horizontal=20.dp,vertical=6.dp).fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(38.dp),shape=RoundedCornerShape(50),color=Green){Box(contentAlignment=Alignment.Center){Text(n.take(1),color=Color.White,fontWeight=FontWeight.Bold)}};Column(Modifier.padding(start=10.dp)){Text(n,fontWeight=FontWeight.Bold);Text("★★★★★  •  Pernah Menyewa",fontSize=10.sp,color=GoldDark)}};Text(c,modifier=Modifier.padding(top=10.dp),fontSize=12.sp,color=Color.DarkGray)}}}

@Composable private fun Owner(onBack:()->Unit,onAdd:()->Unit,onAccount:()->Unit,onNav:(Screen)->Unit){Scaffold(bottomBar={BottomNav(Screen.Owner,onNav)}){p->LazyColumn(Modifier.fillMaxSize().padding(p)){item{TopBar("Dashboard Pemilik",onBack)};item{Text("Selamat Datang,",modifier=Modifier.padding(horizontal=20.dp),color=Color.Gray);Text("Pemilik Hunian",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.padding(horizontal=20.dp))};item{Row(Modifier.padding(20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("3","Properti",Green)};Box(Modifier.weight(1f)){Stat("12","Kamar Tersedia",Gold)};Box(Modifier.weight(1f)){Stat("18","Kamar Terisi",Red)}}};item{Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Action("Tambah Hunian",Icons.Rounded.Add,onAdd)};Box(Modifier.weight(1f)){Action("Kelola Hunian",Icons.Rounded.Home,{})};Box(Modifier.weight(1f)){Action("Statistik",Icons.Rounded.BarChart,{})}}};item{OwnerCard("Pesan Masuk",Icons.Rounded.Email);};item{OwnerCard("Ulasan",Icons.Rounded.Star);};item{OwnerCard("Pengaturan",Icons.Rounded.Settings);};item{Button(onClick=onAccount,modifier=Modifier.fillMaxWidth().padding(20.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("Kelola Akun")}}}}}
@Composable private fun Stat(n:String,l:String,c:Color){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=c.copy(.10f))){Column(Modifier.padding(12.dp)){Text(n,fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=c);Text(l,fontSize=10.sp)}}}
@Composable private fun Action(t:String,i:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(i,null,tint=Green);Text(t,fontSize=10.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)}}}
@Composable private fun OwnerCard(t:String,i:androidx.compose.ui.graphics.vector.ImageVector){Card(Modifier.padding(horizontal=20.dp,vertical=5.dp).fillMaxWidth()){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(i,null,tint=GoldDark);Text(t,fontWeight=FontWeight.Bold,modifier=Modifier.padding(start=10.dp));Spacer(Modifier.weight(1f));Icon(Icons.Rounded.ChevronRight,null)}}}

@Composable private fun AddListing(onBack:()->Unit,onDone:()->Unit){var step by remember{mutableStateOf(1)};LazyColumn(Modifier.fillMaxSize()){item{TopBar("Tambah Hunian",onBack)};item{Row(Modifier.fillMaxWidth().padding(horizontal=20.dp),horizontalArrangement=Arrangement.SpaceBetween){(1..4).forEach{n->Surface(Modifier.size(34.dp),shape=RoundedCornerShape(50),color=if(n<=step)Gold else Soft){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Text(n.toString(),fontWeight=FontWeight.Bold)}}}}};item{Column(Modifier.padding(20.dp)){when(step){1->{Text("Apa yang Anda sewakan?",fontSize=21.sp,fontWeight=FontWeight.ExtraBold);ChoiceRow(listOf("Kos","Kontrakan","Rumah","Kamar"))};2->{Text("Nama Hunian",fontWeight=FontWeight.Bold);OutlinedTextField(value="Kos Melati",onValueChange={},modifier=Modifier.fillMaxWidth(),label={Text("Nama")});Text("Harga / bulan",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=15.dp));OutlinedTextField(value="Rp 750.000",onValueChange={},modifier=Modifier.fillMaxWidth(),label={Text("Harga")})};3->{Text("Lokasi",fontWeight=FontWeight.Bold);Button(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("📍 Pilih Lokasi di Peta",color=Ink)};Text("Fasilitas",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=18.dp));ChoiceRow(listOf("Wi-Fi","AC","Parkir","Dapur","Air"))};4->{Text("Foto Hunian",fontSize=21.sp,fontWeight=FontWeight.ExtraBold);AsyncImage(model=demoListings.first().image,contentDescription=null,modifier=Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)),contentScale=ContentScale.Crop);Text("Tambahkan foto asli hunian agar pencari lebih percaya.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=8.dp))}};Button(onClick={if(step<4)step++ else onDone()},modifier=Modifier.fillMaxWidth().padding(top=25.dp),colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text(if(step<4)"Lanjutkan" else "Publikasikan",color=Ink,fontWeight=FontWeight.Bold)}}}}}

@Composable
private fun Account(onBack:()->Unit,onNav:(Screen)->Unit){
    Scaffold(bottomBar={BottomNav(Screen.Account,onNav)}) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p)) {
            item { TopBar("Akun Saya",onBack) }
            item {
                Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically) {
                    Surface(Modifier.size(62.dp),shape=RoundedCornerShape(50),color=Green) { Box(contentAlignment=Alignment.Center) { Text("Z",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold) } }
                    Column(Modifier.padding(start=14.dp)) { Text("Zulfan Ariadi",fontWeight=FontWeight.Bold,fontSize=18.sp); Text("+62 812 3456 7890",fontSize=11.sp,color=Color.Gray) }
                }
            }
            item {
                Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)){Stat("12","Favorit",Green)}
                    Box(Modifier.weight(1f)){Stat("8","Dilihat",Gold)}
                    Box(Modifier.weight(1f)){Stat("3","Ulasan",Red)}
                }
            }
            items(listOf("Edit Profil","Riwayat Pencarian","Hunian Favorit","Pengaturan Notifikasi","Pusat Bantuan","Tentang HunianPangker")) { t -> OwnerCard(t,Icons.Rounded.ChevronRight) }
            item { Button(onClick={},modifier=Modifier.fillMaxWidth().padding(20.dp),colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("Keluar")} }
        }
    }
}
