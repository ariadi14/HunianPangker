package com.hunianpangker.app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

/**
 * Firebase data layer for HunianPangker.
 * UI remains unchanged while Firebase infrastructure is prepared.
 */
class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun currentUser() = auth.currentUser

    fun register(
        name: String,
        email: String,
        password: String,
        role: String,
        onResult: (Result<Unit>) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid == null) {
                    onResult(Result.failure(IllegalStateException("Firebase UID tidak tersedia.")))
                    return@addOnSuccessListener
                }
                val profile = mapOf(
                    "nama" to name.trim(),
                    "email" to email.trim(),
                    "role" to role,
                    "foto" to "",
                    "createdAt" to System.currentTimeMillis()
                )
                db.collection("users").document(uid).set(profile)
                    .addOnSuccessListener { onResult(Result.success(Unit)) }
                    .addOnFailureListener { onResult(Result.failure(it)) }
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun login(email: String, password: String, onResult: (Result<Unit>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun saveUserProfile(uid: String, values: Map<String, Any?>, onResult: (Result<Unit>) -> Unit) {
        db.collection("users").document(uid).set(values, SetOptions.merge())
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun logout() = auth.signOut()
}
