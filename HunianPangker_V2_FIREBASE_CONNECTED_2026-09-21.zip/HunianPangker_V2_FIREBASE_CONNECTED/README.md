# HunianPangker — V2 Firebase Connected Foundation

This source keeps the 10-screen HunianPangker blueprint unchanged while preparing the Android app for Firebase.

## Firebase integration
- Firebase Android package: `com.hunianpangker.app`
- Google Services Gradle plugin: 4.5.0
- Firebase Android BoM: 34.19.0
- Firebase Authentication: Email/Password
- Cloud Firestore: `(default)` in `asia-southeast2 (Jakarta)`
- `FirebaseRepository.kt`: registration, login, profile storage, current user, logout
- `firestore.rules`: own-user profile access only; other collections remain closed

## Important
The source includes `app/google-services.json` for the registered Android app. Do not replace it with a different Firebase project file.

The UI blueprint was not redesigned in this Firebase foundation step.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`

The included workflow runs `:app:assembleDebug` and uploads the debug APK artifact.
