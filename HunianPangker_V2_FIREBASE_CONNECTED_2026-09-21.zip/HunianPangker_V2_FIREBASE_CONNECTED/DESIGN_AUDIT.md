# Audit Blueprint V1 — HunianPangker

| # | Blueprint | Implementasi V1 |
|---|---|---|
| 1 | Splash Screen | `Splash()` memakai logo resmi HunianPangker |
| 2 | Beranda | `Home()` dengan header, pencarian, kategori, banner, listing terbaru, CTA pemilik |
| 3 | Pencarian & Filter | `Search()` + filter lokasi, harga, jenis, fasilitas, tipe penghuni |
| 4 | Hasil Pencarian | `Results()` + listing, rating, status tersedia, akses peta |
| 5 | Peta Lokasi | `MapScreen()` dengan marker harga dan kartu listing |
| 6 | Detail Hunian | `Detail()` dengan foto, harga, rating, fasilitas, deskripsi, WhatsApp |
| 7 | Ulasan & Rating | `Reviews()` dengan rating dan badge “Pernah Menyewa” |
| 8 | Dashboard Pemilik | `Owner()` dengan properti, kamar, statistik, pesan, ulasan, pengaturan |
| 9 | Tambah Hunian | `AddListing()` 4 langkah: tipe, identitas/harga, lokasi/fasilitas, foto |
| 10 | Akun Pengguna | `Account()` dengan profil, favorit, riwayat, bantuan, pengaturan |

## Identitas visual
- Background utama putih.
- Aksen kuning keemasan, hijau, merah, hitam.
- Logo HunianPangker dan label PANGKALAN KERINCI.
- Tagline: “Cari Hunian dan Temukan Kenyamananmu di Sini”.
- Rounded cards, hierarchy typography, status pills, bottom navigation.

## Audit fungsi V1
- Navigasi antar 10 layar tersedia.
- Pencarian menuju hasil.
- Hasil menuju detail.
- Detail menuju ulasan.
- Hasil menuju peta.
- Beranda dan akun memakai bottom navigation.
- Pemilik dapat membuka dashboard dan wizard tambah hunian.
- Tombol WhatsApp pada detail membuka WhatsApp melalui intent.
- Data listing masih DEMO/local; Firebase, autentikasi nyata, verifikasi identitas, review terverifikasi server-side, dan live map adalah tahap backend berikutnya.
