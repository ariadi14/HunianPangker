# HunianPangker — V2 Firebase Connected Foundation

This source keeps the 10-screen HunianPangker blueprint unchanged while preparing the Android app for Firebase.

## Firebase integration
- Firebase Android package: `com.hunianpangker.app`
- Google Services Gradle plugin: 4.5.0
- Firebase Android BoM: 34.19.0
- Firebase Authentication: Email/Password
- Cloud Firestore: `(default)` in `asia-southeast2 (Jakarta)`
- `FirebaseRepository.kt`: registration, login, profile storage, current user, logout
- `firestore.rules`: own-user profile access only; other collections remain closed

## Important
The source includes `app/google-services.json` for the registered Android app. Do not replace it with a different Firebase project file.

The UI blueprint was not redesigned in this Firebase foundation step.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`

The included workflow runs `:app:assembleDebug` and uploads the debug APK artifact.


## Audit & Implementation 2026-09-23
- Removed all hard-coded demo listing/review data from the application source.
- Hunian data is read from Firestore `listings`; an empty database shows an empty state.
- Added Firebase Auth login/register and owner/user roles.
- Added Firestore listing, favorites, and reviews flows.
- Added responsive scroll layouts and real click actions for the main blueprint screens.
- Added OpenStreetMap map view and location coordinates for listings.
- Final visual implementation follows the locked HunianPangker 10-screen blueprint; elements are built as Android UI rather than a single pasted blueprint image.
- Build must still be verified by GitHub Actions because Gradle/Android SDK are not available in this execution environment.

## Final Blueprint Audit — 2026-09-23

Implemented the locked HunianPangker 10-screen blueprint as native responsive Compose UI rather than a single pasted mockup image.

- Splash: premium HunianPangker identity, Pangkalan Kerinci, green/gold/red visual language.
- Beranda: search, categories, hero, latest listings, favorites and navigation.
- Pencarian & Filter: location, price, type, facilities and tenant type.
- Hasil Pencarian: list/map toggle, listing cards and favorites.
- Peta Lokasi: Pangkalan Kerinci map view, price markers and listing preview.
- Detail Hunian: gallery image, availability, rating, facilities, description, WhatsApp, save and share.
- Ulasan & Rating: rating summary, distribution bars, tabs and write-review flow.
- Dashboard Pemilik: property statistics, owner actions, promotion panel and property management.
- Tambah Hunian: four-step flow, location, facilities and Firebase Storage photo upload.
- Akun Pengguna: profile, phone, dynamic favorites/views/review counters, menu actions and logout.
- Firebase Auth, Firestore, Storage, favorites, reviews and listing CRUD connected.
- Firestore and Storage security rules included.
- Demo listing/review seed data is not included in source.

Build verification must still be performed by GitHub Actions because this environment does not have the Android/Gradle dependency cache required for a full Android compile.
