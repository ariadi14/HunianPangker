package com.hunianpangker.app

import android.content.Context
import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage

class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {
    fun currentUser() = auth.currentUser

    fun register(name: String, email: String, password: String, role: String, onResult: (Result<Unit>) -> Unit) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid == null) return@addOnSuccessListener onResult(Result.failure(IllegalStateException("Firebase UID tidak tersedia.")))
                val profile = mapOf(
                    "nama" to name.trim(), "email" to email.trim(), "role" to role,
                    "telepon" to "", "foto" to "", "createdAt" to System.currentTimeMillis()
                )
                db.collection("users").document(uid).set(profile)
                    .addOnSuccessListener { onResult(Result.success(Unit)) }
                    .addOnFailureListener { onResult(Result.failure(it)) }
            }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun login(email: String, password: String, onResult: (Result<Unit>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun logout() = auth.signOut()

    fun getUser(uid: String, onResult: (Result<Map<String, Any>>) -> Unit) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { onResult(Result.success(it.data ?: emptyMap())) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun saveUserProfile(uid: String, values: Map<String, Any?>, onResult: (Result<Unit>) -> Unit) {
        db.collection("users").document(uid).set(values, SetOptions.merge())
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listings(onResult: (Result<List<Listing>>) -> Unit) {
        db.collection("listings").get()
            .addOnSuccessListener { snap ->
                val result = snap.documents.mapNotNull { Listing.from(it.id, it.data ?: emptyMap()) }
                    .sortedByDescending { it.createdAt }
                onResult(Result.success(result))
            }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun saveListing(listing: Listing, onResult: (Result<String>) -> Unit) {
        val ref = if (listing.id.isBlank()) db.collection("listings").document() else db.collection("listings").document(listing.id)
        val uid = auth.currentUser?.uid ?: return onResult(Result.failure(IllegalStateException("Silakan masuk sebagai pemilik.")))
        val fixed = listing.copy(id = ref.id, ownerId = uid, createdAt = if (listing.createdAt == 0L) System.currentTimeMillis() else listing.createdAt)
        ref.set(fixed.toMap()).addOnSuccessListener { onResult(Result.success(ref.id)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun deleteListing(id: String, onResult: (Result<Unit>) -> Unit) {
        db.collection("listings").document(id).delete()
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun incrementView(listing: Listing) {
        db.collection("listings").document(listing.id).update("views", listing.views + 1L)
    }

    fun isFavorite(listingId: String, onResult: (Boolean) -> Unit) {
        val uid = auth.currentUser?.uid ?: return onResult(false)
        db.collection("users").document(uid).collection("favorites").document(listingId).get()
            .addOnSuccessListener { onResult(it.exists()) }.addOnFailureListener { onResult(false) }
    }

    fun favorites(onResult: (Result<List<String>>) -> Unit) {
        val uid = auth.currentUser?.uid ?: return onResult(Result.success(emptyList()))
        db.collection("users").document(uid).collection("favorites").get()
            .addOnSuccessListener { onResult(Result.success(it.documents.map { d -> d.id })) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun setFavorite(listingId: String, favorite: Boolean, onResult: (Result<Unit>) -> Unit) {
        val uid = auth.currentUser?.uid ?: return onResult(Result.failure(IllegalStateException("Silakan masuk terlebih dahulu.")))
        val ref = db.collection("users").document(uid).collection("favorites").document(listingId)
        val task = if (favorite) {
            ref.set(mapOf("createdAt" to System.currentTimeMillis()))
        } else {
            ref.delete()
        }
        task.addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun reviews(listingId: String, onResult: (Result<List<Review>>) -> Unit) {
        db.collection("listings").document(listingId).collection("reviews").get()
            .addOnSuccessListener { snap ->
                onResult(Result.success(snap.documents.mapNotNull { Review.from(it.id, it.data ?: emptyMap()) }.sortedByDescending { it.createdAt }))
            }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun addReview(listingId: String, rating: Int, text: String, onResult: (Result<Unit>) -> Unit) {
        val u = auth.currentUser ?: return onResult(Result.failure(IllegalStateException("Silakan masuk terlebih dahulu.")))
        val ref = db.collection("listings").document(listingId).collection("reviews").document()
        val review = Review(ref.id, u.uid, u.displayName ?: "Pengguna", rating, text.trim(), false, System.currentTimeMillis())
        ref.set(review.toMap()).addOnSuccessListener { onResult(Result.success(Unit)) }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun uploadImage(context: Context, uri: Uri, path: String, onResult: (Result<String>) -> Unit) {
        val ref = storage.reference.child(path)
        val stream = try { context.contentResolver.openInputStream(uri) } catch (_: Exception) { null }
        if (stream == null) return onResult(Result.failure(IllegalStateException("Foto tidak dapat dibaca.")))
        ref.putStream(stream).addOnSuccessListener {
            stream.close()
            ref.downloadUrl.addOnSuccessListener { onResult(Result.success(it.toString())) }
                .addOnFailureListener { onResult(Result.failure(it)) }
        }.addOnFailureListener { stream.close(); onResult(Result.failure(it)) }
    }
}

data class Listing(
    val id: String = "", val title: String = "", val type: String = "Kos", val price: Long = 0,
    val address: String = "", val distance: String = "", val rating: Double = 0.0, val reviews: Int = 0,
    val image: String = "", val available: String = "Tersedia", val facilities: Set<String> = emptySet(),
    val description: String = "", val lat: Double = -0.422, val lng: Double = 103.365,
    val ownerId: String = "", val tenant: String = "Bebas", val views: Long = 0, val createdAt: Long = 0L
) {
    fun toMap() = mapOf(
        "title" to title, "type" to type, "price" to price, "address" to address,
        "distance" to distance, "rating" to rating, "reviews" to reviews, "image" to image,
        "available" to available, "facilities" to facilities.toList(), "description" to description,
        "lat" to lat, "lng" to lng, "ownerId" to ownerId, "tenant" to tenant,
        "views" to views, "createdAt" to createdAt
    )
    companion object {
        fun from(id: String, m: Map<String, Any>): Listing? {
            val title = m["title"] as? String ?: return null
            return try {
                Listing(
                    id = id, title = title, type = m["type"] as? String ?: "Kos",
                    price = (m["price"] as? Number)?.toLong() ?: 0L, address = m["address"] as? String ?: "",
                    distance = m["distance"] as? String ?: "", rating = (m["rating"] as? Number)?.toDouble() ?: 0.0,
                    reviews = (m["reviews"] as? Number)?.toInt() ?: 0, image = m["image"] as? String ?: "",
                    available = m["available"] as? String ?: "Tersedia", facilities = (m["facilities"] as? List<*>)?.filterIsInstance<String>()?.toSet() ?: emptySet(),
                    description = m["description"] as? String ?: "", lat = (m["lat"] as? Number)?.toDouble() ?: -0.422,
                    lng = (m["lng"] as? Number)?.toDouble() ?: 103.365, ownerId = m["ownerId"] as? String ?: "",
                    tenant = m["tenant"] as? String ?: "Bebas", views = (m["views"] as? Number)?.toLong() ?: 0L,
                    createdAt = (m["createdAt"] as? Number)?.toLong() ?: 0L
                )
            } catch (_: Exception) { null }
        }
    }
}

data class Review(
    val id: String = "", val userId: String = "", val userName: String = "Pengguna", val rating: Int = 5,
    val text: String = "", val verifiedTenant: Boolean = false, val createdAt: Long = 0L
) {
    fun toMap() = mapOf("userId" to userId, "userName" to userName, "rating" to rating, "text" to text, "verifiedTenant" to verifiedTenant, "createdAt" to createdAt)
    companion object { fun from(id:String,m:Map<String,Any>)=Review(id,m["userId"] as? String ?: "",m["userName"] as? String ?: "Pengguna",(m["rating"] as? Number)?.toInt() ?: 5,m["text"] as? String ?: "",m["verifiedTenant"] as? Boolean ?: false,(m["createdAt"] as? Number)?.toLong() ?: 0L) }
}
