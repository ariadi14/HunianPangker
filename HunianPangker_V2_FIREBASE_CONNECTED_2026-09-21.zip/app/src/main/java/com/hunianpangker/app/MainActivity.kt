package com.hunianpangker.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil3.compose.AsyncImage
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale

private val Gold = Color(0xFFF2B632)
private val GoldDark = Color(0xFFB77B00)
private val Green = Color(0xFF1F6B45)
private val GreenDark = Color(0xFF0E3D2B)
private val Red = Color(0xFFC73535)
private val Ink = Color(0xFF111111)
private val Soft = Color(0xFFF7F7F3)
private val Line = Color(0xFFE6E2D8)

private enum class Screen { Splash, Home, Search, Results, Map, Detail, Reviews, Favorites, Messages, Owner, Add, Account, Auth }
private data class Filters(
    val query: String = "", val type: String = "Semua", val price: String = "Semua",
    val facilities: Set<String> = emptySet(), val tenant: String = "Semua"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HunianTheme { App() } }
    }
}

@Composable
private fun HunianTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Color.White, surface = Color.White),
        typography = Typography()
    ) { content() }
}

@Composable
private fun App() {
    val repo = remember { FirebaseRepository() }
    var screen by remember { mutableStateOf(Screen.Splash) }
    var data by remember { mutableStateOf<List<Listing>>(emptyList()) }
    var selected by remember { mutableStateOf<Listing?>(null) }
    var filters by remember { mutableStateOf(Filters()) }
    var refresh by remember { mutableIntStateOf(0) }

    fun reload() {
        repo.listings { result -> result.onSuccess { data = it }.onFailure { data = emptyList() } }
    }

    LaunchedEffect(refresh) { reload() }
    LaunchedEffect(Unit) {
        delay(1100)
        screen = if (repo.currentUser() == null) Screen.Home else Screen.Home
    }

    val filtered = data.filter { l ->
        (filters.query.isBlank() || l.title.contains(filters.query, true) || l.address.contains(filters.query, true)) &&
        (filters.type == "Semua" || l.type == filters.type) &&
        (filters.price == "Semua" || when (filters.price) {
            "< 500rb" -> l.price < 500_000
            "500rb - 1jt" -> l.price in 500_000..999_999
            "1jt - 2jt" -> l.price in 1_000_000..1_999_999
            else -> l.price >= 2_000_000
        }) &&
        (filters.facilities.isEmpty() || filters.facilities.all { f -> f in l.facilities }) &&
        (filters.tenant == "Semua" || l.tenant == filters.tenant)
    }

    fun openListing(l: Listing) {
        selected = l
        repo.incrementView(l)
        screen = Screen.Detail
    }

    when (screen) {
        Screen.Splash -> Splash()
        Screen.Home -> Home(repo, data, { screen = Screen.Search }, ::openListing, { screen = it }, { screen = Screen.Auth })
        Screen.Search -> Search(filters, { filters = it }, { screen = Screen.Results }, { screen = Screen.Home })
        Screen.Results -> Results(repo, filtered, { screen = Screen.Search }, { screen = Screen.Map }, ::openListing, { screen = it })
        Screen.Map -> MapScreen(repo, filtered, { screen = Screen.Results }, ::openListing)
        Screen.Detail -> selected?.let { Detail(repo, it, { screen = Screen.Results }, { screen = Screen.Reviews }, { screen = Screen.Auth }, { refresh++ }) }
        Screen.Reviews -> selected?.let { Reviews(repo, it, { screen = Screen.Detail }) }
        Screen.Favorites -> Favorites(repo, data, ::openListing, { screen = it })
        Screen.Messages -> Messages({ screen = Screen.Home })
        Screen.Owner -> Owner(repo, data, { screen = Screen.Add }, { screen = Screen.Account }, { refresh++ }, { screen = it })
        Screen.Add -> AddListing(repo, { screen = Screen.Owner }, { refresh++ })
        Screen.Account -> Account(repo, data, { screen = Screen.Home }, { screen = it })
        Screen.Auth -> Auth(repo, { screen = Screen.Home }, { screen = Screen.Owner })
    }
}

@Composable
private fun Splash() {
    Box(Modifier.fillMaxSize().background(Color.White)) {
        Box(Modifier.fillMaxWidth().height(250.dp).align(Alignment.BottomCenter).background(Brush.horizontalGradient(listOf(GreenDark, Green, Gold))))
        Box(Modifier.fillMaxSize().padding(bottom = 120.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(R.drawable.hunianpangker_logo, null, Modifier.size(180.dp), contentScale = ContentScale.Fit)
                Text("HunianPangker", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text("Cari Hunian dan Temukan\nKenyamananmu di Sini", fontSize = 13.sp, color = Green, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 7.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
                    Icon(Icons.Rounded.LocationOn, null, tint = GoldDark, modifier = Modifier.size(18.dp))
                    Text("PANGKALAN KERINCI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldDark, letterSpacing = 1.2.sp)
                }
            }
        }
        Text("Rumah\nuntuk Cerita\nLebih Baik", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 42.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun LogoHeader(onAccount: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(R.drawable.hunianpangker_logo, null, Modifier.size(46.dp), contentScale = ContentScale.Fit)
        Column(Modifier.padding(start = 10.dp)) {
            Text("HunianPangker", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("PANGKALAN KERINCI", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Green, letterSpacing = 1.6.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onAccount) { Icon(Icons.Rounded.NotificationsNone, "Notifikasi") }
    }
}

@Composable
private fun BottomNav(active: Screen, onNav: (Screen) -> Unit) {
    val items = listOf(
        Screen.Home to ("Beranda" to Icons.Rounded.Home), Screen.Search to ("Cari" to Icons.Rounded.Search),
        Screen.Favorites to ("Favorit" to Icons.Rounded.FavoriteBorder), Screen.Messages to ("Pesan" to Icons.Rounded.ChatBubbleOutline),
        Screen.Account to ("Akun" to Icons.Rounded.Person)
    )
    NavigationBar(containerColor = Color.White) {
        items.forEach { (s, pair) -> NavigationBarItem(selected = active == s, onClick = { onNav(s) }, icon = { Icon(pair.second, null) }, label = { Text(pair.first, fontSize = 10.sp) }) }
    }
}

@Composable
private fun OwnerBottomNav(active: Screen, onNav: (Screen) -> Unit) {
    val items = listOf(
        Screen.Owner to ("Beranda" to Icons.Rounded.Home), Screen.Add to ("Hunian" to Icons.Rounded.HomeWork),
        Screen.Owner to ("Statistik" to Icons.Rounded.BarChart), Screen.Messages to ("Pesan" to Icons.Rounded.ChatBubbleOutline),
        Screen.Account to ("Akun" to Icons.Rounded.Person)
    )
    NavigationBar(containerColor = Color.White) {
        items.forEach { (s, pair) -> NavigationBarItem(selected = false, onClick = { onNav(s) }, icon = { Icon(pair.second, null) }, label = { Text(pair.first, fontSize = 10.sp) }) }
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali") }
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
private fun SearchBox(onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 2.dp,
        border = BorderStroke(1.dp, Line)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = Green)
            Text("Mau cari hunian apa?", color = Color.Gray, modifier = Modifier.padding(start = 10.dp))
            Spacer(Modifier.weight(1f))
            Icon(Icons.Rounded.Tune, null, tint = GoldDark)
        }
    }
}

@Composable
private fun Home(repo: FirebaseRepository, data: List<Listing>, onSearch: () -> Unit, onSelect: (Listing) -> Unit, onNav: (Screen) -> Unit, onAccount: () -> Unit) {
    Scaffold(bottomBar = { BottomNav(Screen.Home, onNav) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p)) {
            item { LogoHeader(onAccount) }
            item { Box(Modifier.padding(horizontal = 20.dp)) { SearchBox(onSearch) }; Spacer(Modifier.height(16.dp)) }
            item {
                Text("Kategori Populer", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
                LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(listOf("Kos" to Icons.Rounded.Business, "Kontrakan" to Icons.Rounded.HomeWork, "Rumah" to Icons.Rounded.Home, "Kamar" to Icons.Rounded.Bed)) { Category(it.first, it.second) }
                }
            }
            item {
                Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(155.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(GreenDark, Green)))) {
                    Icon(Icons.Rounded.Home, null, tint = Gold.copy(alpha = .18f), modifier = Modifier.size(170.dp).align(Alignment.CenterEnd))
                    Column(Modifier.padding(20.dp)) {
                        Text("Temukan Hunian Ideal", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("di Pangkalan Kerinci", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
                        Text("Nyaman • Strategis • Terpercaya", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(20.dp, 18.dp, 20.dp, 8.dp)) {
                    Text("Hunian Terbaru", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f)); Text("Lihat Semua >", color = GoldDark, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onSearch))
                }
            }
            if (data.isEmpty()) item { EmptyState("Belum ada hunian", "Belum ada data. Tambahkan hunian dari Dashboard Pemilik.") }
            else items(data.take(5), key = { it.id }) { ListingCard(repo, it, onSelect) }
            item { Button({ onNav(Screen.Owner) }, Modifier.padding(20.dp).fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Dashboard Pemilik", color = Ink, fontWeight = FontWeight.Bold) } }
        }
    }
}

@Composable
private fun Category(title: String, icon: ImageVector) {
    Surface(shape = RoundedCornerShape(16.dp), color = Soft, border = BorderStroke(1.dp, Line)) {
        Column(Modifier.width(82.dp).padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(27.dp)); Spacer(Modifier.height(7.dp)); Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ListingCard(repo: FirebaseRepository, l: Listing, onClick: (Listing) -> Unit) {
    var favorite by remember(l.id) { mutableStateOf(false) }
    LaunchedEffect(l.id) { repo.isFavorite(l.id) { favorite = it } }
    Card(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().clickable { onClick(l) }, RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (l.image.isBlank()) Box(Modifier.size(98.dp).clip(RoundedCornerShape(14.dp)).background(Soft), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Home, null, tint = Green, modifier = Modifier.size(40.dp)) }
            else AsyncImage(l.image, null, Modifier.size(98.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(l.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f)); StatusPill(l.available) }
                Text(rupiah(l.price) + "/bulan", color = GoldDark, fontWeight = FontWeight.Bold)
                Text(l.address.ifBlank { "Pangkalan Kerinci" }, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("★ ${if (l.rating == 0.0) "-" else "%.1f".format(l.rating)}", color = GoldDark, fontSize = 11.sp); Text("  (${l.reviews})", fontSize = 11.sp, color = Color.Gray); if (l.distance.isNotBlank()) Text("  •  ${l.distance}", fontSize = 11.sp, color = Color.Gray) }
            }
            IconButton(onClick = { favorite = !favorite; repo.setFavorite(l.id, favorite) {} }) { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (favorite) Red else Green) }
        }
    }
}

@Composable private fun StatusPill(text: String) { Surface(shape = RoundedCornerShape(50), color = if (text.contains("Segera")) Gold.copy(.18f) else Green.copy(.12f)) { Text(text, fontSize = 9.sp, color = if (text.contains("Segera")) GoldDark else Green, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)) } }

@Composable
private fun Search(filters: Filters, onChange: (Filters) -> Unit, onApply: () -> Unit, onBack: () -> Unit) {
    val facilities = listOf("Wi-Fi", "Kamar Mandi Dalam", "AC", "Parkir Motor", "Parkir Mobil", "Dapur", "Listrik Termasuk", "Air Termasuk")
    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar("Cari Hunian", onBack) }
        item { OutlinedTextField(filters.query, { onChange(filters.copy(query = it)) }, Modifier.fillMaxWidth().padding(horizontal = 20.dp), singleLine = true, leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Cari lokasi atau nama hunian...") }) }
        item { SectionTitle("Lokasi"); Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.LocationOn, null, tint = Green); Text("Pangkalan Kerinci", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp)); Spacer(Modifier.weight(1f)); TextButton(onClick = {}) { Text("Ganti", color = GoldDark) } } }
        item { SectionTitle("Harga / bulan"); ChipRow(listOf("< 500rb", "500rb - 1jt", "1jt - 2jt", "> 2jt"), filters.price) { onChange(filters.copy(price = if (filters.price == it) "Semua" else it)) } }
        item { SectionTitle("Jenis Hunian"); ChipRow(listOf("Kos", "Kontrakan", "Rumah", "Kamar"), filters.type) { onChange(filters.copy(type = if (filters.type == it) "Semua" else it)) } }
        item { SectionTitle("Fasilitas"); FacilityGrid(facilities, filters.facilities) { f -> onChange(filters.copy(facilities = if (f in filters.facilities) filters.facilities - f else filters.facilities + f)) } }
        item { SectionTitle("Tipe Penghuni"); ChipRow(listOf("Putra", "Putri", "Keluarga", "Bebas"), filters.tenant) { onChange(filters.copy(tenant = if (filters.tenant == it) "Semua" else it)) } }
        item { Button(onClick = onApply, modifier = Modifier.fillMaxWidth().padding(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Terapkan Filter", color = Ink, fontWeight = FontWeight.Bold) } }
    }
}

@Composable private fun SectionTitle(text: String) { Text(text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 8.dp)) }

@Composable
private fun ChipRow(options: List<String>, selected: String, onSelected: (String) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { option -> FilterChip(selected = selected == option, onClick = { onSelected(option) }, label = { Text(option) }) }
    }
}

@Composable
private fun FacilityGrid(options: List<String>, selected: Set<String>, onSelected: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { row.forEach { f -> FilterChip(selected = f in selected, onClick = { onSelected(f) }, label = { Text(f, fontSize = 11.sp) }, modifier = Modifier.weight(1f)) } } }
    }
}

@Composable
private fun Results(repo: FirebaseRepository, data: List<Listing>, onBack: () -> Unit, onMap: () -> Unit, onSelect: (Listing) -> Unit, onNav: (Screen) -> Unit) {
    var listMode by remember { mutableStateOf(true) }
    Scaffold(bottomBar = { BottomNav(Screen.Search, onNav) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p)) {
            item { TopBar("Hasil Pencarian", onBack) }
            item { Surface(modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(14.dp), color = Soft, border = BorderStroke(1.dp, Line)) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.LocationOn, null, tint = Green); Text("Pangkalan Kerinci", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp)); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.Tune, null, tint = GoldDark) } } }
            item { Row(Modifier.padding(20.dp, 15.dp, 20.dp, 5.dp), verticalAlignment = Alignment.CenterVertically) { Text("${data.size} hunian ditemukan", fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); FilterChip(selected = !listMode, onClick = { listMode = false }, label = { Text("Peta") }); Spacer(Modifier.width(5.dp)); FilterChip(selected = listMode, onClick = { listMode = true }, label = { Text("Daftar") }) } }
            if (!listMode) item { MapPreview(data, onMap) }
            else if (data.isEmpty()) item { EmptyState("Hunian tidak ditemukan", "Coba ubah kata kunci atau filter pencarian.") }
            else items(data, key = { it.id }) { ListingCard(repo, it, onSelect) }
        }
    }
}

@Composable private fun MapPreview(data: List<Listing>, onMap: () -> Unit) { Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(310.dp).clip(RoundedCornerShape(20.dp))) { MapWebView(data); Button(onClick = onMap, modifier = Modifier.align(Alignment.BottomCenter).padding(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Buka Peta", color = Ink, fontWeight = FontWeight.Bold) } } }

@Composable
private fun MapScreen(repo: FirebaseRepository, data: List<Listing>, onBack: () -> Unit, onSelect: (Listing) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Peta Lokasi", onBack, action = { IconButton(onClick = {}) { Icon(Icons.Rounded.Search, null) } })
        Surface(modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(14.dp), color = Color.White, border = BorderStroke(1.dp, Line)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Search, null, tint = Green); Text("Cari di area ini", color = Color.Gray, modifier = Modifier.padding(start = 8.dp)) } }
        Box(Modifier.padding(12.dp).fillMaxWidth().weight(1f).clip(RoundedCornerShape(20.dp))) { MapWebView(data) }
        data.firstOrNull()?.let { l -> Card(Modifier.padding(12.dp).fillMaxWidth().clickable { onSelect(l) }, RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Line)) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { if (l.image.isBlank()) Box(Modifier.size(75.dp).background(Soft), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Home, null, tint = Green) } else AsyncImage(l.image, null, Modifier.size(75.dp), contentScale = ContentScale.Crop); Column(Modifier.padding(start = 10.dp).weight(1f)) { Text(l.title, fontWeight = FontWeight.Bold); Text(rupiah(l.price) + "/bulan", color = GoldDark, fontWeight = FontWeight.Bold); Text(l.address, fontSize = 11.sp, color = Color.Gray); Row { StatusPill(l.available); Text("  ★ ${"%.1f".format(l.rating)} (${l.reviews})", fontSize = 11.sp, color = GoldDark) } } } } }
    }
}

@Composable
private fun MapWebView(data: List<Listing>) {
    val html = remember(data) { mapHtml(data) }
    AndroidView(factory = { context: Context -> WebView(context).apply { settings.javaScriptEnabled = true; webViewClient = WebViewClient(); loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null) } }, modifier = Modifier.fillMaxSize())
}

private fun mapHtml(data: List<Listing>): String {
    val markers = data.joinToString(",") { "{lat:${it.lat},lng:${it.lng},price:'${rupiahShort(it.price)}',title:'${it.title.replace("'", "\\'")}' }" }
    return """
    <html><head><meta name='viewport' content='width=device-width,initial-scale=1'/><style>html,body,#m{height:100%;margin:0}body{background:#dce9df;font-family:sans-serif}.title{position:absolute;z-index:3;left:12px;top:12px;background:white;padding:10px 14px;border-radius:18px;box-shadow:0 2px 10px #0002;color:#174b35;font-weight:700}.pin{position:absolute;transform:translate(-50%,-50%);background:#f2b632;color:#111;padding:7px 9px;border-radius:15px;font-weight:800;box-shadow:0 2px 6px #0003}</style></head><body><div id='m'><div class='title'>Pangkalan Kerinci</div><div id='pins'></div></div><script>const a=[$markers];const p=document.getElementById('pins');const base={lat:-0.422,lng:103.365};function pos(x){return {left:(50+(x.lng-base.lng)*2500)+'%',top:(50-(x.lat-base.lat)*2500)+'%'}}a.forEach(x=>{let e=document.createElement('div');e.className='pin';e.innerText=x.price;let q=pos(x);e.style.left=q.left;e.style.top=q.top;e.title=x.title;p.appendChild(e)});</script></body></html>
    """.replace("[$markers]", "[$markers]")
}

@Composable
private fun Detail(repo: FirebaseRepository, listing: Listing, onBack: () -> Unit, onReviews: () -> Unit, onLogin: () -> Unit, onRefresh: () -> Unit) {
    val context = LocalContext.current
    var favorite by remember { mutableStateOf(false) }
    var share by remember { mutableStateOf(false) }
    LaunchedEffect(listing.id) { repo.isFavorite(listing.id) { favorite = it } }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box(Modifier.fillMaxWidth().height(280.dp)) {
                if (listing.image.isBlank()) Box(Modifier.fillMaxSize().background(Soft), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Home, null, tint = Green, modifier = Modifier.size(100.dp)) }
                else AsyncImage(listing.image, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) { IconButton(onClick = onBack) { Surface(shape = CircleShape, color = Color.White.copy(.92f)) { Icon(Icons.Rounded.ArrowBack, null, modifier = Modifier.padding(8.dp)) } }; Row { IconButton(onClick = { share = true }) { Surface(shape = CircleShape, color = Color.White.copy(.92f)) { Icon(Icons.Rounded.Share, null, modifier = Modifier.padding(8.dp)) } }; IconButton(onClick = { if (repo.currentUser() == null) onLogin() else { favorite = !favorite; repo.setFavorite(listing.id, favorite) {} } }) { Surface(shape = CircleShape, color = Color.White.copy(.92f)) { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (favorite) Red else Green, modifier = Modifier.padding(8.dp)) } } } }
            }
        }
        item { Column(Modifier.padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { StatusPill(listing.available); Spacer(Modifier.weight(1f)); Text("★ ${"%.1f".format(listing.rating)} (${listing.reviews} ulasan)", color = GoldDark, fontWeight = FontWeight.Bold) }; Text(listing.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp)); Text(rupiah(listing.price) + "/bulan", fontSize = 20.sp, color = GoldDark, fontWeight = FontWeight.ExtraBold); Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.LocationOn, null, tint = Green); Column(Modifier.padding(start = 5.dp)) { Text(listing.address.ifBlank { "Jl. Lintas Timur, Pangkalan Kerinci" }, fontSize = 13.sp); Text(if (listing.distance.isBlank()) "Pangkalan Kerinci" else "${listing.distance} dari lokasi Anda", fontSize = 11.sp, color = Color.Gray) } } } }
        item { SectionTitle("Fasilitas"); LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(if (listing.facilities.isEmpty()) listOf("Wi-Fi", "AC", "Kamar Mandi Dalam", "Parkir Motor", "Dapur") else listing.facilities.toList()) { FacilityPill(it) } } }
        item { Column(Modifier.padding(20.dp)) { Text("Deskripsi", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold); Text(listing.description.ifBlank { "Hunian nyaman di Pangkalan Kerinci dengan lingkungan aman dan strategis." }, modifier = Modifier.padding(top = 8.dp), lineHeight = 21.sp) } }
        item { Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { openWhatsApp(context, "Halo, saya tertarik dengan ${listing.title} di HunianPangker.") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Icon(Icons.Rounded.Chat, null); Spacer(Modifier.width(5.dp)); Text("Hubungi Pemilik") }; OutlinedButton(onClick = { if (repo.currentUser() == null) onLogin() else { favorite = !favorite; repo.setFavorite(listing.id, favorite) {} } }, modifier = Modifier.weight(.55f)) { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null); Spacer(Modifier.width(4.dp)); Text("Simpan") } } }
        item { OutlinedButton(onClick = onReviews, modifier = Modifier.fillMaxWidth().padding(20.dp)) { Text("Ulasan & Rating") } }
    }
    if (share) { AlertDialog(onDismissRequest = { share = false }, title = { Text("Bagikan Hunian") }, text = { Text("Bagikan ${listing.title} ke aplikasi lain.") }, confirmButton = { Button(onClick = { share = false; val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${listing.title}\n${rupiah(listing.price)}/bulan\n${listing.address}") }; context.startActivity(Intent.createChooser(intent, "Bagikan")) }) { Text("Bagikan") } }) }
}

@Composable private fun FacilityPill(text: String) { Surface(shape = RoundedCornerShape(14.dp), color = Soft, border = BorderStroke(1.dp, Line)) { Column(Modifier.width(88.dp).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(iconFor(text), null, tint = Green, modifier = Modifier.size(23.dp)); Text(text, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 5.dp)) } } }
private fun iconFor(text: String): ImageVector = when { text.contains("Wi", true) -> Icons.Rounded.Wifi; text.contains("AC", true) -> Icons.Rounded.AcUnit; text.contains("Parkir", true) -> Icons.Rounded.TwoWheeler; text.contains("Dapur", true) -> Icons.Rounded.Restaurant; text.contains("Air", true) -> Icons.Rounded.WaterDrop; else -> Icons.Rounded.Bathtub }

@Composable
private fun Reviews(repo: FirebaseRepository, listing: Listing, onBack: () -> Unit) {
    var reviews by remember { mutableStateOf<List<Review>>(emptyList()) }
    var tab by remember { mutableStateOf("Semua") }
    var write by remember { mutableStateOf(false) }
    LaunchedEffect(listing.id) { repo.reviews(listing.id) { it.onSuccess { reviews = it } } }
    val shown = reviews.filter { tab == "Semua" || (tab == "Pernah Menyewa" && it.verifiedTenant) || tab == "Terbaru" }
    val average = if (reviews.isEmpty()) 0.0 else reviews.map { it.rating }.average()
    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar("Ulasan & Rating", onBack) }
        item { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(110.dp)) { Text(if (reviews.isEmpty()) "4.8" else "%.1f".format(average), fontSize = 38.sp, fontWeight = FontWeight.ExtraBold); Text("★★★★★", color = Gold, fontSize = 18.sp); Text("dari 5", fontSize = 11.sp, color = Color.Gray); Text("${if (reviews.isEmpty()) listing.reviews else reviews.size} ulasan", fontSize = 11.sp) }; Column(Modifier.weight(1f)) { (5 downTo 1).forEach { star -> RatingBar(star, reviews.count { it.rating == star }, reviews.size) } } } }
        item { ChipRow(listOf("Semua", "Pernah Menyewa", "Terbaru"), tab) { tab = it } }
        if (shown.isEmpty()) item { EmptyState("Belum ada ulasan", "Jadilah yang pertama menulis ulasan untuk hunian ini.") }
        else items(shown, key = { it.id }) { ReviewCard(it) }
        item { Button(onClick = { if (repo.currentUser() != null) write = true }, modifier = Modifier.fillMaxWidth().padding(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Tulis Ulasan", color = Ink, fontWeight = FontWeight.Bold) } }
    }
    if (write) WriteReviewDialog(repo, listing.id, { write = false }) { write = false; repo.reviews(listing.id) { it.onSuccess { reviews = it } } }
}

@Composable private fun RatingBar(star: Int, count: Int, total: Int) { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) { Text("$star ★", fontSize = 10.sp, modifier = Modifier.width(34.dp)); LinearProgressIndicator(progress = { if (total == 0) 0f else count.toFloat() / total }, modifier = Modifier.weight(1f).height(6.dp), color = Gold, trackColor = Soft); Text(if (total == 0) "0%" else "${count * 100 / total}%", fontSize = 9.sp, modifier = Modifier.width(35.dp).padding(start = 5.dp)) } }

@Composable private fun ReviewCard(r: Review) { Card(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(), RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Line)) { Column(Modifier.padding(14.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Surface(shape = CircleShape, color = Green) { Text(r.userName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp)) }; Column(Modifier.padding(start = 10.dp)) { Text(r.userName, fontWeight = FontWeight.Bold); if (r.verifiedTenant) StatusPill("Pernah Menyewa") }; Spacer(Modifier.weight(1f)); Text("★★★★★".take(r.rating), color = Gold) }; Text(r.text, modifier = Modifier.padding(top = 8.dp), lineHeight = 19.sp) } } }

@Composable private fun WriteReviewDialog(repo: FirebaseRepository, listingId: String, onDismiss: () -> Unit, onSaved: () -> Unit) { var rating by remember { mutableIntStateOf(5) }; var text by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("Tulis Ulasan") }, text = { Column { Text("Rating", fontWeight = FontWeight.Bold); Row { (1..5).forEach { n -> IconButton(onClick = { rating = n }) { Icon(Icons.Rounded.Star, null, tint = if (n <= rating) Gold else Line) } } }; OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Bagikan pengalaman Anda") }, minLines = 3) } }, confirmButton = { Button(onClick = { repo.addReview(listingId, rating, text) { if (it.isSuccess) onSaved() } }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Kirim", color = Ink) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }) }

@Composable
private fun Favorites(repo: FirebaseRepository, all: List<Listing>, onSelect: (Listing) -> Unit, onNav: (Screen) -> Unit) {
    var ids by remember { mutableStateOf<Set<String>>(emptySet()) }
    LaunchedEffect(Unit) { repo.favorites { it.onSuccess { ids = it.toSet() } } }
    val mine = all.filter { it.id in ids }
    Scaffold(bottomBar = { BottomNav(Screen.Favorites, onNav) }) { p -> LazyColumn(Modifier.fillMaxSize().padding(p)) { item { TopBar("Hunian Favorit", { onNav(Screen.Home) }) }; if (mine.isEmpty()) item { EmptyState("Belum ada favorit", "Tekan ikon hati pada kartu atau Detail Hunian untuk menyimpan hunian.") } else items(mine) { ListingCard(repo, it, onSelect) } } }
}

@Composable private fun Messages(onBack: () -> Unit) { LazyColumn(Modifier.fillMaxSize()) { item { TopBar("Pesan", onBack) }; item { EmptyState("Belum ada pesan", "Percakapan dengan pemilik akan muncul di sini.") } } }

@Composable
private fun Owner(repo: FirebaseRepository, data: List<Listing>, onAdd: () -> Unit, onAccount: () -> Unit, onRefresh: () -> Unit, onNav: (Screen) -> Unit) {
    val uid = repo.currentUser()?.uid
    val mine = data.filter { it.ownerId == uid }
    var dialog by remember { mutableStateOf<String?>(null) }
    val available = mine.count { !it.available.contains("Segera", true) }
    val occupied = mine.count { it.available.contains("Terisi", true) }
    Scaffold(bottomBar = { OwnerBottomNav(Screen.Owner, onNav) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p)) {
            item { Row(Modifier.fillMaxWidth().padding(20.dp, 15.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Selamat Datang,", fontSize = 16.sp, color = Color.Gray); Text("Pemilik Hunian", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold) }; Surface(shape = CircleShape, color = Soft) { Icon(Icons.Rounded.NotificationsNone, null, tint = Green, modifier = Modifier.padding(10.dp)) } } }
            item { Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = GreenDark)) { Column(Modifier.padding(18.dp)) { Text("Hunian Saya", color = Gold, fontWeight = FontWeight.Bold); Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OwnerStat("${mine.size}", "Properti", Color(0xFF55A77C), Modifier.weight(1f)); OwnerStat("$available", "Kamar Tersedia", Gold, Modifier.weight(1f)); OwnerStat("$occupied", "Kamar Terisi", Color(0xFFE76B72), Modifier.weight(1f)) } } } }
            item { Row(Modifier.padding(20.dp, 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { SmallStat("${mine.sumOf { it.views }}", "Dilihat", Modifier.weight(1f)); SmallStat("0", "Calon Penyewa", Modifier.weight(1f)) } }
            item { SectionTitle("Menu Pemilik") }
            item { ActionGrid(listOf("Tambah Hunian" to Icons.Rounded.AddCircle, "Kelola Hunian" to Icons.Rounded.Edit, "Statistik" to Icons.Rounded.BarChart, "Pesan Masuk" to Icons.Rounded.ChatBubbleOutline, "Ulasan" to Icons.Rounded.Star, "Pengaturan" to Icons.Rounded.Settings)) { dialog = it; if (it == "Tambah Hunian") onAdd() } }
            item { Card(Modifier.padding(20.dp).fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Gold.copy(.18f))) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Campaign, null, tint = GoldDark, modifier = Modifier.size(36.dp)); Column(Modifier.padding(start = 10.dp).weight(1f)) { Text("Promosikan Hunian Anda", fontWeight = FontWeight.ExtraBold); Text("Jangkau lebih banyak penyewa", fontSize = 12.sp, color = Color.Gray) }; Button({ dialog = "Promosi" }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Mulai Promosi", color = Ink, fontSize = 11.sp) } } } }
            item { SectionTitle("Hunian Saya") }
            if (mine.isEmpty()) item { EmptyState("Belum ada properti", "Tekan Tambah Hunian untuk menerbitkan properti pertama Anda.") }
            else items(mine, key = { it.id }) { l -> OwnerListingCard(repo, l, onRefresh) }
            item { Button(onClick = onAccount, modifier = Modifier.fillMaxWidth().padding(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Akun") } }
        }
    }
    if (dialog != null) { OwnerDialog(dialog!!, mine, repo) { dialog = null; onRefresh() } }
}

@Composable private fun OwnerStat(number: String, label: String, color: Color, modifier: Modifier = Modifier) { Column(modifier) { Text(number, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = color); Text(label, color = Color.White, fontSize = 10.sp) } }
@Composable private fun SmallStat(number: String, label: String, modifier: Modifier = Modifier) { Card(modifier, RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line)) { Column(Modifier.padding(13.dp)) { Text(number, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Green); Text(label, fontSize = 10.sp, color = Color.Gray) } } }

@Composable private fun ActionGrid(actions: List<Pair<String, ImageVector>>, onClick: (String) -> Unit) { Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { actions.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (title, icon) -> Card(Modifier.weight(1f).clickable { onClick(title) }, RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line)) { Column(Modifier.height(94.dp).fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = Green); Text(title, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 5.dp)) } } } } } } }

@Composable private fun OwnerListingCard(repo: FirebaseRepository, listing: Listing, onRefresh: () -> Unit) { var delete by remember { mutableStateOf(false) }; Card(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth(), RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line)) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { if (listing.image.isBlank()) Box(Modifier.size(70.dp).background(Soft), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Home, null, tint = Green) } else AsyncImage(listing.image, null, Modifier.size(70.dp), contentScale = ContentScale.Crop); Column(Modifier.padding(start = 10.dp).weight(1f)) { Text(listing.title, fontWeight = FontWeight.Bold); Text(rupiah(listing.price) + "/bulan", color = GoldDark); StatusPill(listing.available) }; IconButton(onClick = { delete = true }) { Icon(Icons.Rounded.DeleteOutline, null, tint = Red) } } }; if (delete) AlertDialog(onDismissRequest = { delete = false }, title = { Text("Hapus hunian?") }, text = { Text("Data ${listing.title} akan dihapus dari Firebase.") }, confirmButton = { Button(onClick = { repo.deleteListing(listing.id) { delete = false; onRefresh() } }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Hapus") } }, dismissButton = { TextButton({ delete = false }) { Text("Batal") } }) }

@Composable private fun OwnerDialog(title: String, mine: List<Listing>, repo: FirebaseRepository, onClose: () -> Unit) { val body = when (title) { "Kelola Hunian" -> if (mine.isEmpty()) "Belum ada properti." else mine.joinToString("\n") { "• ${it.title} — ${rupiah(it.price)}/bulan" }; "Statistik" -> "Total properti: ${mine.size}\nTotal dilihat: ${mine.sumOf { it.views }}\nHunian tersedia: ${mine.count { it.available == "Tersedia" }}"; "Pesan Masuk" -> "Belum ada pesan masuk."; "Ulasan" -> "Ulasan akan tampil di halaman Ulasan & Rating setiap hunian."; "Pengaturan" -> "Pengaturan pemilik tersimpan melalui Firebase."; "Promosi" -> "Promosi siap dikembangkan tanpa mengubah data hunian."; else -> "" }; AlertDialog(onDismissRequest = onClose, title = { Text(title) }, text = { Text(body) }, confirmButton = { Button(onClick = onClose) { Text("Tutup") } }) }

@Composable
private fun AddListing(repo: FirebaseRepository, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    var step by remember { mutableIntStateOf(1) }
    var type by remember { mutableStateOf("Kos") }; var tenant by remember { mutableStateOf("Putri") }; var title by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; var lat by remember { mutableStateOf(-0.422) }; var lng by remember { mutableStateOf(103.365) }
    var facilities by remember { mutableStateOf(setOf<String>()) }; var imageUri by remember { mutableStateOf<Uri?>(null) }; var imageUrl by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; var uploading by remember { mutableStateOf(false) }; var locationDialog by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> imageUri = u }
    val fs = listOf("Wi-Fi", "Kamar Mandi Dalam", "AC", "Parkir Motor", "Parkir Mobil", "Dapur", "Listrik Termasuk", "Air Termasuk")
    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar("Tambah Hunian", onBack) }
        item { Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceBetween) { (1..4).forEach { n -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Surface(modifier = Modifier.size(34.dp), shape = CircleShape, color = if (n <= step) Gold else Soft) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(n.toString(), fontWeight = FontWeight.Bold) } }; Text(if (n == 1) "Dasar" else if (n == 2) "Harga" else if (n == 3) "Lokasi" else "Foto", fontSize = 9.sp, color = Color.Gray) } } } }
        item { Column(Modifier.padding(20.dp)) {
            when (step) {
                1 -> { Text("Apa yang Anda sewakan?", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(10.dp)); SelectCards(listOf("Kos" to Icons.Rounded.Business, "Kontrakan" to Icons.Rounded.HomeWork, "Rumah" to Icons.Rounded.Home, "Kamar" to Icons.Rounded.Bed), type) { type = it }; SectionTitle("Tipe Penghuni"); ChipRow(listOf("Putra", "Putri", "Keluarga", "Bebas"), tenant) { tenant = it } }
                2 -> { Text("Nama Hunian", fontWeight = FontWeight.Bold); OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Contoh: Kos Melati") }, singleLine = true); Text("Harga / bulan", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 15.dp)); OutlinedTextField(price, { price = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Rp 750.000") }, singleLine = true); Text("Alamat", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 15.dp)); OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("Jl. Lintas Timur, Pangkalan Kerinci") }, minLines = 2) }
                3 -> { Text("Lokasi", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text(address.ifBlank { "Pangkalan Kerinci" }, color = Color.Gray, modifier = Modifier.padding(top = 6.dp)); Button(onClick = { locationDialog = true }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Icon(Icons.Rounded.LocationOn, null, tint = Ink); Spacer(Modifier.width(6.dp)); Text("Pilih Lokasi di Peta", color = Ink, fontWeight = FontWeight.Bold) }; Text("Koordinat: ${"%.5f".format(lat)}, ${"%.5f".format(lng)}", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp)); SectionTitle("Fasilitas"); FacilityGrid(fs, facilities) { f -> facilities = if (f in facilities) facilities - f else facilities + f }; OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("Deskripsi") }, minLines = 3) }
                4 -> { Text("Foto Hunian", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); if (imageUri != null) AsyncImage(imageUri, null, Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)).background(Soft), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AddPhotoAlternate, null, tint = Green, modifier = Modifier.size(55.dp)) }; Button(onClick = { picker.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth().padding(top = 12.dp)) { Text(if (imageUri == null) "Pilih Foto" else "Ganti Foto") }; Text("Gunakan foto asli hunian agar calon penyewa mendapat informasi yang akurat.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp)) }
            }
            if (error.isNotBlank()) Text(error, color = Red, modifier = Modifier.padding(top = 12.dp))
            Button(onClick = {
                if (step < 4) { if (step == 2 && (title.isBlank() || price.toLongOrNull() == null || address.isBlank())) error = "Lengkapi nama, harga, dan alamat." else { error = ""; step++ } }
                else {
                    val n = price.toLongOrNull(); val u = repo.currentUser()
                    if (u == null) error = "Silakan masuk sebagai pemilik terlebih dahulu."
                    else if (title.isBlank() || n == null || n <= 0) error = "Data belum lengkap."
                    else if (imageUri == null) publishListing(repo, title, type, n, address, lat, lng, facilities, tenant, desc, "", onDone) { error = it }
                    else { uploading = true; repo.uploadImage(context, imageUri!!, "listings/${u.uid}/${System.currentTimeMillis()}.jpg") { r -> r.onSuccess { url -> publishListing(repo, title, type, n, address, lat, lng, facilities, tenant, desc, url, onDone) { error = it }; uploading = false }.onFailure { uploading = false; error = it.message ?: "Gagal upload foto" } } }
                }
            }, Modifier.fillMaxWidth().padding(top = 22.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold), enabled = !uploading) { Text(if (uploading) "Mengunggah..." else if (step < 4) "Lanjutkan" else "Publikasikan", color = Ink, fontWeight = FontWeight.Bold) }
        } }
    }
    if (locationDialog) AlertDialog(onDismissRequest = { locationDialog = false }, title = { Text("Pilih Lokasi di Peta") }, text = { Column { Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(15.dp))) { MapWebView(emptyList()) }; Text("Untuk akurasi, gunakan titik pusat Pangkalan Kerinci atau isi koordinat di bawah.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(lat.toString(), { lat = it.toDoubleOrNull() ?: lat }, Modifier.weight(1f), label = { Text("Lat") }); OutlinedTextField(lng.toString(), { lng = it.toDoubleOrNull() ?: lng }, Modifier.weight(1f), label = { Text("Lng") }) } } }, confirmButton = { Button(onClick = { locationDialog = false }) { Text("Gunakan Lokasi") } })
}

private fun publishListing(repo: FirebaseRepository, title: String, type: String, price: Long, address: String, lat: Double, lng: Double, facilities: Set<String>, tenant: String, desc: String, image: String, onDone: () -> Unit, onError: (String) -> Unit) {
    repo.saveListing(Listing(title = title, type = type, price = price, address = address, lat = lat, lng = lng, facilities = facilities, tenant = tenant, description = desc, image = image)) { r -> r.onSuccess { onDone() }.onFailure { onError(it.message ?: "Gagal menyimpan hunian") } }
}

@Composable private fun SelectCards(options: List<Pair<String, ImageVector>>, selected: String, onSelect: (String) -> Unit) { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { options.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { row.forEach { (name, icon) -> Card(Modifier.weight(1f).clickable { onSelect(name) }, RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = if (selected == name) Gold.copy(.18f) else Soft), border = BorderStroke(1.dp, if (selected == name) Gold else Line)) { Column(Modifier.height(92.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = if (selected == name) GoldDark else Green); Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) } } } } } }}

@Composable
private fun Account(repo: FirebaseRepository, data: List<Listing>, onBack: () -> Unit, onNav: (Screen) -> Unit) {
    val u = repo.currentUser(); var name by remember { mutableStateOf("Pengguna") }; var phone by remember { mutableStateOf("+62") }; var email by remember { mutableStateOf(u?.email ?: "") }; var favoriteCount by remember { mutableIntStateOf(0) }; var dialog by remember { mutableStateOf<String?>(null) }; var edit by remember { mutableStateOf(false) }
    LaunchedEffect(u?.uid) { u?.uid?.let { repo.getUser(it) { r -> r.onSuccess { m -> name = m["nama"] as? String ?: "Pengguna"; phone = m["telepon"] as? String ?: "+62" } }; repo.favorites { r -> r.onSuccess { favoriteCount = it.size } } } }
    val views = data.sumOf { it.views }
    Scaffold(bottomBar = { BottomNav(Screen.Account, onNav) }) { p -> LazyColumn(Modifier.fillMaxSize().padding(p)) {
        item { TopBar("Akun Saya", onBack) }
        item { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Surface(modifier = Modifier.size(72.dp), shape = CircleShape, color = Green) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(name.take(1).uppercase(), color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold) } }; Column(Modifier.padding(start = 14.dp)) { Text(name, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold); Text(phone, fontSize = 12.sp, color = Color.Gray); Text(email, fontSize = 11.sp, color = Color.Gray) } } }
        item { Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AccountStat(favoriteCount.toString(), "Favorit", Modifier.weight(1f)); AccountStat(views.toString(), "Dilihat", Modifier.weight(1f)); AccountStat("0", "Ulasan", Modifier.weight(1f)) } }
        val menus = listOf("Edit Profil" to Icons.Rounded.Edit, "Riwayat Pencarian" to Icons.Rounded.History, "Hunian Favorit" to Icons.Rounded.FavoriteBorder, "Pengaturan Notifikasi" to Icons.Rounded.NotificationsNone, "Pusat Bantuan" to Icons.Rounded.HelpOutline, "Tentang HunianPangker" to Icons.Rounded.Info)
        items(menus) { (title, icon) -> Card(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth().clickable { if (title == "Edit Profil") edit = true else if (title == "Hunian Favorit") onNav(Screen.Favorites) else dialog = title }, RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Line)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Green); Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.ChevronRight, null, tint = Color.Gray) } } }
        item { Button(onClick = { repo.logout(); onNav(Screen.Home) }, Modifier.fillMaxWidth().padding(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Keluar") } }
    } }
    if (edit) AlertDialog(onDismissRequest = { edit = false }, title = { Text("Edit Profil") }, text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Nama") }); OutlinedTextField(phone, { phone = it }, label = { Text("Nomor Telepon") }, modifier = Modifier.padding(top = 8.dp)) } }, confirmButton = { Button(onClick = { u?.uid?.let { repo.saveUserProfile(it, mapOf("nama" to name, "telepon" to phone)) { edit = false } } }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = { edit = false }) { Text("Batal") } })
    if (dialog != null) AlertDialog(onDismissRequest = { dialog = null }, title = { Text(dialog!!) }, text = { Text(when (dialog) { "Riwayat Pencarian" -> "Riwayat pencarian akan menampilkan pencarian yang tersimpan pada sesi berikutnya."; "Pengaturan Notifikasi" -> "Notifikasi dapat diaktifkan ketika modul notifikasi aplikasi dihubungkan."; "Pusat Bantuan" -> "Gunakan Cari untuk menemukan hunian dan Dashboard Pemilik untuk menerbitkan hunian."; else -> "HunianPangker — Cari Hunian dan Temukan Kenyamananmu di Sini." }) }, confirmButton = { Button(onClick = { dialog = null }) { Text("Tutup") } })
}

@Composable private fun AccountStat(number: String, label: String, modifier: Modifier = Modifier) { Card(modifier, RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Line)) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(number, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Green); Text(label, fontSize = 10.sp, color = Color.Gray) } } }

@Composable
private fun Auth(repo: FirebaseRepository, onUser: () -> Unit, onOwner: () -> Unit) {
    var register by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var role by remember { mutableStateOf("user") }; var error by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { AsyncImage(R.drawable.hunianpangker_logo, null, Modifier.size(125.dp)); Text(if (register) "Buat Akun" else "Masuk ke HunianPangker", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp)) }
        if (register) item { OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth().padding(top = 20.dp), label = { Text("Nama") }, singleLine = true) }
        item { OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth().padding(top = 10.dp), label = { Text("Email") }, singleLine = true) }
        item { OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth().padding(top = 10.dp), label = { Text("Password") }, singleLine = true) }
        if (register) item { SectionTitle("Jenis Akun"); ChipRow(listOf("user", "owner"), role) { role = it } }
        if (error.isNotBlank()) item { Text(error, color = Red, modifier = Modifier.padding(top = 10.dp)) }
        item { Button(onClick = { if (register) repo.register(name, email, password, role) { r -> r.onSuccess { if (role == "owner") onOwner() else onUser() }.onFailure { error = it.message ?: "Gagal membuat akun" } } else repo.login(email, password) { r -> r.onSuccess { onUser() }.onFailure { error = it.message ?: "Login gagal" } } }, Modifier.fillMaxWidth().padding(top = 20.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text(if (register) "Daftar" else "Masuk", color = Ink, fontWeight = FontWeight.Bold) } }
        item { TextButton(onClick = { register = !register; error = "" }) { Text(if (register) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar") } }
    }
}

@Composable private fun EmptyState(title: String, message: String) { Column(Modifier.fillMaxWidth().padding(35.dp), horizontalAlignment = Alignment.CenterHorizontally) { Surface(shape = CircleShape, color = Soft) { Icon(Icons.Rounded.HomeWork, null, tint = Green, modifier = Modifier.padding(18.dp).size(32.dp)) }; Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(top = 12.dp)); Text(message, color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp)) } }

private fun openWhatsApp(context: Context, text: String) { val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(text))); try { context.startActivity(intent) } catch (_: Exception) { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Hubungi Pemilik")) } }
private fun rupiah(value: Long): String = "Rp " + NumberFormat.getNumberInstance(Locale("id", "ID")).format(value)
private fun rupiahShort(value: Long): String = when { value >= 1_000_000 -> "Rp ${value / 1_000_000}jt"; value >= 1_000 -> "Rp ${value / 1_000}rb"; else -> "Rp $value" }
